import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class CoordinatesFilter implements Filter<JSONObject> {
    @Override
    public JSONObject execute(JSONObject input) {
        JSONObject geometryJsonObject= new JSONObject();
        geometryJsonObject = (JSONObject) input.get("geometry");
        JSONArray coordinatesJsonArray=(JSONArray) geometryJsonObject.get("coordinates");
        JSONObject returnObject = new JSONObject();
        returnObject.put("coordinates",coordinatesJsonArray);

        JSONObject properties= new JSONObject();
        JSONObject InputProps=(JSONObject) input.get("properties");
        properties.put("city",InputProps.get("addr:city"));
        properties.put("name",InputProps.get("name"));
        properties.put("street",InputProps.get("addr:street"));
        returnObject.put("properties",properties);

        return returnObject;
    }
}
