package com.example.dians_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiansDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
