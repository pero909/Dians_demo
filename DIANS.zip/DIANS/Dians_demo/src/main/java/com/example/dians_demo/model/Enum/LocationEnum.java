package com.example.dians_demo.model.Enum;

public enum LocationEnum {
    HOTEL,
    RESTAURANT,
    GYM
}
